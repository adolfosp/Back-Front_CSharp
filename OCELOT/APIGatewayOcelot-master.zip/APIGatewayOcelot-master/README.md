# APIGatewayOcelot

[![Build status](https://ci.appveyor.com/api/projects/status/v77otyf7i8ko47vx?svg=true)](https://ci.appveyor.com/project/thiagoloureiro/apigatewayocelot)

[![Build history](https://buildstats.info/appveyor/chart/thiagoloureiro/apigatewayocelot)](https://ci.appveyor.com/project/thiagoloureiro/apigatewayocelot/history)

.NET5 API Gateway
 - Ocelot
 - Consul Service Discovery
 - Load Balance
 - JWT (Json Web Tokens)
