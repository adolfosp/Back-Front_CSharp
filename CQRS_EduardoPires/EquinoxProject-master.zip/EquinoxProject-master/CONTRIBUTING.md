If want contribute start opening an issue to discuss first
